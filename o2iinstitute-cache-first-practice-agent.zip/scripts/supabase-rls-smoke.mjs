import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";

import { createClient } from "@supabase/supabase-js";
import dotenv from "dotenv";

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
dotenv.config({ path: resolve(__dirname, "..", ".env.local") });

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

function assert(condition, message) {
  if (!condition) throw new Error(message);
}

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error("Missing NEXT_PUBLIC_SUPABASE_URL or NEXT_PUBLIC_SUPABASE_ANON_KEY.");
}

const anon = createClient(supabaseUrl, supabaseAnonKey);
const { data: nodes, error: nodesError } = await anon
  .from("taxonomy_nodes")
  .select("tag_id,status")
  .eq("status", "active")
  .limit(5);
assert(!nodesError, `taxonomy_nodes public read failed: ${nodesError?.message}`);
assert(Array.isArray(nodes), "taxonomy_nodes did not return an array");
console.log("PASS public can read active taxonomy nodes");

const { data: rpcRows, error: rpcError } = await anon.rpc("search_questions_by_taxonomy", {
  assignment_review_status: "approved",
  difficulty_max: 1000,
  difficulty_min: 0,
  exclude_tag_ids: [],
  include_tag_ids: [],
  page_limit: 1,
  page_offset: 0,
  query_text: null,
  question_status: "published",
});
assert(!rpcError, `public taxonomy search RPC failed: ${rpcError?.message}`);
assert(Array.isArray(rpcRows), "taxonomy search RPC did not return rows");
console.log("PASS public can call taxonomy search RPC for published approved content");

const { error: insertError } = await anon.from("taxonomy_nodes").insert({
  tag_id: `math.concept.rls_denied_${Date.now()}`,
  node_kind: "tag",
  subject_tag_id: "math",
  facet_key: "concept",
  label: "RLS denied",
  is_assignable: true,
  status: "active",
});
assert(insertError, "anon unexpectedly inserted taxonomy_nodes");
console.log("PASS anon cannot write taxonomy nodes");
